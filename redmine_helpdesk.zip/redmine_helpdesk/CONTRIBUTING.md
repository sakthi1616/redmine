# Issues

Please note that I cannot provide user support for this open source project. All issues related to user support will be closed without a further comment. Open source does not mean that I have unlimited time to solve problems of others for free!

If you need professional help please [contact me](http://www.qutic.com/support "hire a consultant") directly - I am for hire.

If you find a bug please create an issue in the tracker, write a patch and send me a pull request :-)
